package wsClient;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class testServlet
 */
@WebServlet("/testServlet")
public class testServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public testServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		
		String[] mainData = new String[7];
		String[] sensorData = new String[11];
		String[] moduleData = new String[4];
		
		mainData[0] = request.getParameter("b1");
		mainData[1] = request.getParameter("b2");
		mainData[2] = request.getParameter("b3");
		mainData[3] = request.getParameter("o1");
		mainData[4] = request.getParameter("o2");
		mainData[5] = request.getParameter("o3");
		mainData[6] = request.getParameter("o4");
		
		sensorData[0] = request.getParameter("s11");
		sensorData[1] = request.getParameter("s12");
		sensorData[2] = request.getParameter("s13");
		sensorData[3] = request.getParameter("s14");
		sensorData[4] = request.getParameter("s15");
		sensorData[5] = request.getParameter("s21");
		sensorData[6] = request.getParameter("s22");
		sensorData[7] = request.getParameter("s23");
		sensorData[8] = request.getParameter("s24");
		sensorData[9] = request.getParameter("s25");
		sensorData[10] = request.getParameter("s26");
		
		moduleData[0] = new String().format("P1�S�x�Ѽ�(%s), P2�����ǲ߰Ѽ�(%s), P3�S�x�ӷ����(%s), P4�Ѯ𪬪p(%s), P5���ߪ��p(%s), P6�����K����(%s), P7�a�I(%s)",
				request.getParameter("m11"), request.getParameter("m12"), request.getParameter("m13"), request.getParameter("m14"),
				request.getParameter("m15"), request.getParameter("m16"), request.getParameter("m17"));
		moduleData[1] = new String().format("P1�S�x�Ѽ�(%s), P2�����ǲ߰Ѽ�(%s), P3�S�x�ӷ����(%s), P4�Ѯ𪬪p(%s), P5���ߪ��p(%s), P6�����K����(%s), P7�a�I(%s)",
				request.getParameter("m21"), request.getParameter("m22"), request.getParameter("m23"), request.getParameter("m24"),
				request.getParameter("m25"), request.getParameter("m26"), request.getParameter("m27"));
		moduleData[2] = new String().format("P1�v���G�׸��(%s), P2���бӷP��(%s), P3������O�_������ɶ�(%s)",
				request.getParameter("m31"), request.getParameter("m32"), request.getParameter("m33"));
		moduleData[3] = new String().format("P1�k���D�ӷP��(%s), P2�����D�ӷP��(%s), P3�w�]�������D�̤p�e��(%s),P4�w�]�������D�̤j�e��(%s), P5ĵ�i�ӷP��(%s), P6�D���������Ѧ^���ɶ�����(%s)",
				request.getParameter("m41"), request.getParameter("m42"), request.getParameter("m43"),
				request.getParameter("m44"), request.getParameter("m45"), request.getParameter("m46"));
		
		carEvent.eventCenter.processEventData(restfulws.JsonProcess.doEncode(mainData, sensorData, moduleData));
		
	}

}
