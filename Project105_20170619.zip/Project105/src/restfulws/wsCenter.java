package restfulws;

import esTrans.preTransCenter;
import restfulws.JsonProcess;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("DataService")
public class wsCenter {
	
	@GET
	@Path("/carPath/{carID}/{timestamp}/{eventID}")
	@Produces(MediaType.TEXT_XML)
	public void carPath(
			@PathParam("carID") String carID,
			@PathParam("timestamp") String timestamp,
			@PathParam("eventID") String eventID) {
		wsClient.clientOfPlanII.getMedium(carID, timestamp, eventID);
	}
	
	@GET
	@Path("/databasePath/{carID}/{timestamp}/{eventID}")
	@Produces(MediaType.TEXT_XML)
	public String databasePath(
			@PathParam("carID") String carID,
			@PathParam("timestamp") String timestamp,
			@PathParam("eventID") String eventID) {
		return restfulws.JsonProcess.doEncode();
	}
	
	@GET
	@Path("/recommendSolution/{eventID}")
	@Produces(MediaType.TEXT_XML)
	public void recommendSolution(@PathParam("eventID") int eventID) {
		esTrans.preTransCenter.recommendSolutionA(eventID);
	}

}
