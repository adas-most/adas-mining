package esTrans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class preTransCenter {
	
	public static double[] sameValue = {1.0, 0.1, 0.1};
	public static double[] similarValue = {1.0, 10.0, 10.0};
	
	double[] sameEventIDArrary;
	double[] similarEventIDArrary;
	
	public void findSolution (){

	}
	
	public static void recommendSolutionA (int eventID){
		
		// if database empty call recommendSolutionC
		
		// Same events
		
		
		// test use
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String jdbc_info = new String().format("jdbc:mysql://%s/%s", "localhost", "u825104560_ygade");
			Connection conn = DriverManager.getConnection(jdbc_info, "root", "mysqlmysql");
			
			Statement st = conn.createStatement();
			String sql = new String().format("UPDATE `carevent` SET `status`='2' WHERE `id` = %d", eventID);
			st.executeUpdate(sql);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void recommendSolutionB (int eventID){
		
	}
	
	public void recommendSolutionC (int eventID){
		
	}
	
	public static double distance(double[] a, double[] b){
		double sum = 0.0;
		for(int i = 0; i < a.length; i++)
			sum += Math.pow(a[i] - b[i], 2);
		return Math.sqrt(sum);
	}
	
}

class data {
	
	double[] sdlist;
	double[] imgmodlist;
	
	data(int eventID){
		
	}
	
	void connect(){
		
	}
	
	void build(){
		
	}
}