package restfulws;

//import wsClient.clientOfPlanII;
import restfulws.JsonProcess;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("DataService")
public class wsCenter {
	
	@GET
	@Path("/carPath/{carID}/{timestamp}/{eventID}")
	@Produces(MediaType.TEXT_XML)
	public void carPath(
			@PathParam("carID") String carID,
			@PathParam("timestamp") String timestamp,
			@PathParam("eventID") String eventID) {
		wsClient.clientOfPlanII.getMedium(carID, timestamp, eventID);
	}
	
	@GET
	@Path("/databasePath/{carID}/{timestamp}/{eventID}")
	@Produces(MediaType.TEXT_XML)
	public String databasePath(
			@PathParam("carID") String carID,
			@PathParam("timestamp") String timestamp,
			@PathParam("eventID") String eventID) {
		
		JsonProcess json = new JsonProcess();
		String dst = new String().format("%s@-@%s@-@%s@-@%s", carID, timestamp, eventID, json.doEncode());
		System.out.println(dst);
		return dst;
	}

}
