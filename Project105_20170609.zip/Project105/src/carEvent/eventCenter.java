package carEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.json.JsonObject;

import restfulws.JsonProcess;

public class eventCenter {
	
	
	
	public static String carID;
	public static String timestamp;
	public static String eventID;
	
	public static final String BASE_URL = "localhost";
	public static final String USER_NAME = "root";
	public static final String USER_PASSWD = "mysqlmysql";
	public static final String DATABASE_NAME = "u825104560_ygade";
	
	
	public static void connectDatabase(String src){
		
		JsonProcess js = new JsonProcess();
		JsonObject root = js.jsonFromString(src);
		JsonObject monitoring_board_info = root.getJsonObject("monitoring_board_info");
		JsonObject vehicle_info = root.getJsonObject("vehicle_info");
		JsonObject Exception_Event_info = root.getJsonObject("Exception_Event_info");
		JsonObject video_clips_info = root.getJsonObject("video_clips_info");
		
		
		
		Connection conn = null;
		String sql = "";
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://" + BASE_URL + "/" + DATABASE_NAME;
			conn = DriverManager.getConnection(url, USER_NAME, USER_PASSWD);
			
			Statement st = conn.createStatement();
			ResultSet rs;
			
			// save data to carevent
			String location = "E120�X 50\\' 00\" N23�X 39\\' 15\"";
			String videoURL = "https://www.youtube.com/watch?v=vW3dLGLG3K8";
			String sdidlist = save_carSenseData(root, st);	// save data to carSenseData
			String imgmodidlist = save_imgmodule(root, st);	// save data to imgmodule
			sql = new String().format(
					"INSERT INTO carevent (id, createdate, location, type, imgsource, sdidlist, imgmodidlist, status) VALUES (%s, '%s', '%s', '%s', '%s', '%s', '%s', '%s')", 
					eventID, timestamp, location, "1", videoURL, sdidlist, imgmodidlist, "0");
			st.executeUpdate(sql);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static String save_carSenseData(JsonObject json, Statement st){

		String sdidlist = "";

		try {
			String sql = "SELECT MAX(id) FROM carsensedata";
			ResultSet rs = st.executeQuery(sql);
			int first = Integer.parseInt(rs.getString(0)) + 1;
			int index = first;
			
			String[] dataIndex_OBDII = {"����������t(rpm)", "������p�ɳt(km/h)", "�����i��ū�(oC)", "�����N�o����(oC)", "�Ů�y�v(g/s)"};
			JsonObject OBDII_info = json.getJsonObject("OBDII_info");
			for(int i = 0; i < OBDII_info.size(); i++){
				sql = new String().format("INSERT INTO carsensedata (id, name, data) VALUES (%d, '%s', '%s')",
						index++, dataIndex_OBDII[i], OBDII_info.getString(dataIndex_OBDII[i]));
				st.executeUpdate(sql);
			}
						
			String[] dataIndex_OBU = {"�[�t��(m/s2)", "�٨�(Nt)", "�O��(on/off)", "��V�L(��)", "�L��(oC)", "�L��(kg/cm2)"};
			JsonObject OBU_info = json.getJsonObject("OBU_info");
			for(int i = 0; i < OBU_info.size(); i++){
				sql = new String().format("INSERT INTO carsensedata (id, name, data) VALUES (%d, '%s', '%s')",
						index++, dataIndex_OBU[i], OBDII_info.getString(dataIndex_OBU[i]));
				st.executeUpdate(sql);
			}
			
			for(int i = first; i < index; i++)
				sdidlist += "," + i;
			sdidlist = sdidlist.substring(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sdidlist;
	}
	
	public static String save_imgmodule(JsonObject json, Statement st){
		
		String imgmodidlist = "";
		
		try {
			String sql = "SELECT MAX(id) FROM imgmodule";
			ResultSet rs = st.executeQuery(sql);
			System.out.println(rs.getString(0));
			int first = Integer.parseInt(rs.getString(0)) + 1;
			int index = first;
			
			String[] dataIndex_original_parameters = {"���������Ҳ�", "�e�誫�鰻���Ҳ�", "���z�Y�O�Ҳ�", "�D�����������Ҳ�"};
			JsonObject original_parameters_info = json.getJsonObject("original_parameters_info");
			for(int i = 0; i < original_parameters_info.size(); i++){
				String src = original_parameters_info.getString(dataIndex_original_parameters[i]).replaceAll("\\s?P\\d?", "");;
				
				String namelist = src.replaceAll("\\(\\d+\\)", "");
				String valuelist = src.replaceAll("[^\\d+,]", "");
				
				sql = new String().format("INSERT INTO imgmodule (name, modified, paraname, oldpara) VALUES ('%s', '%s', '%s', '%s')",
						dataIndex_original_parameters[i], "1", namelist, valuelist);
				st.executeUpdate(sql);
			}
			
			for(int i = first; i < index; i++)
				imgmodidlist += "," + i;
			imgmodidlist = imgmodidlist.substring(1);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return imgmodidlist;
	}
	
	public static void processDataIn(String input){
		
		String[] data = input.split("@-@");
		
		carID = data[0];
		timestamp = data[1];
		eventID = data[2];
		
		connectDatabase(data[3]);
		
	}

}
